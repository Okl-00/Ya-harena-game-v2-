import { StorageManager } from './storage.js';

// Instance partagée (StorageManager est sans état propre à part son préfixe de clés)
const sharedStorageManager = new StorageManager();

export class UIManager {
    constructor() {
        this.toastContainer = null;
        this.createToastContainer();
    }

    createToastContainer() {
        this.toastContainer = document.createElement('div');
        this.toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(this.toastContainer);
    }

    showToast(message, type = 'info') {
        const id = 'toast_' + Date.now();
        const bgColor = {
            'success': 'bg-success',
            'error': 'bg-danger',
            'warning': 'bg-warning',
            'info': 'bg-info'
        }[type] || 'bg-info';

        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white ${bgColor} border-0`;
        toast.id = id;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        this.toastContainer.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    updateBalance(balance) {
        const balanceElements = document.querySelectorAll('.user-balance');
        balanceElements.forEach(el => {
            el.textContent = `${balance.toLocaleString()} Ar`;
        });
    }

    showUserMenu(user) {
        const menuContainer = document.querySelector('.user-menu-container');
        if (menuContainer) {
            menuContainer.innerHTML = `
                <div class="dropdown">
                    <button class="btn btn-outline-warning dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i> ${user.name}
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" data-page="profile">Profil</a></li>
                        <li><a class="dropdown-item" href="#" data-page="history">Historique</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="casinoApp.authManager.logout()">Déconnexion</a></li>
                    </ul>
                </div>
            `;
        }
    }

    renderHistory(history) {
        const container = document.getElementById('history-container');
        const emptyState = document.getElementById('emptyHistory');

        this.updateHistorySummary(history);
        this.updatePerformanceChart(history);

        if (!container) return;

        if (!history || history.length === 0) {
            container.innerHTML = '<p class="text-center py-4">Aucun historique de jeu</p>';
            if (emptyState) emptyState.style.display = 'block';
            return;
        }

        if (emptyState) emptyState.style.display = 'none';

        let html = `
            <div class="table-responsive">
                <table class="table table-dark table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Jeu</th>
                            <th>Mise</th>
                            <th>Résultat</th>
                            <th>Gain</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        history.forEach(game => {
            const date = new Date(game.timestamp).toLocaleString('fr-FR');
            html += `
                <tr class="${game.win ? 'win-row' : 'loss-row'}">
                    <td>${date}</td>
                    <td>${game.gameName}</td>
                    <td>${game.bet.toLocaleString()} Ar</td>
                    <td class="${game.win ? 'text-success' : 'text-danger'}">
                        ${game.win ? '✅ Gagné' : '❌ Perdu'}
                    </td>
                    <td class="${game.win ? 'text-success' : ''}">
                        ${game.win ? '+' + game.payout.toLocaleString() : '-' + game.bet.toLocaleString()} Ar
                    </td>
                </tr>
            `;
        });

        html += '</tbody></table></div>';
        container.innerHTML = html;
    }

    // Remplit le panneau "Résumé" de la page historique (éléments statiques de history.html)
    updateHistorySummary(history) {
        const totals = (history || []).reduce((acc, g) => {
            acc.games++;
            if (g.win) {
                acc.wins++;
                acc.winnings += g.payout;
            } else {
                acc.losses++;
                acc.lossAmount += g.bet;
            }
            return acc;
        }, { games: 0, wins: 0, losses: 0, winnings: 0, lossAmount: 0 });

        const set = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };

        set('totalGames', totals.games);
        set('totalWins', totals.wins);
        set('totalLosses', totals.losses);
        set('totalWinnings', `${totals.winnings.toLocaleString()} Ar`);
        set('totalLossesAmount', `${totals.lossAmount.toLocaleString()} Ar`);
    }

    // Crée (ou met à jour) le graphique d'évolution des gains/pertes de la page historique.
    // La logique était auparavant dans un <script> inline de history.html, qui ne peut pas
    // s'exécuter car la page est injectée via innerHTML.
    updatePerformanceChart(history) {
        const canvas = document.getElementById('performanceChart');
        if (!canvas || typeof Chart === 'undefined') return;

        const chronological = [...(history || [])].reverse();
        let cumulative = 0;
        const labels = [];
        const data = [];
        chronological.forEach(g => {
            cumulative += g.win ? g.payout : -g.bet;
            labels.push(new Date(g.timestamp).toLocaleDateString('fr-FR'));
            data.push(cumulative);
        });

        if (window.performanceChart) {
            window.performanceChart.data.labels = labels;
            window.performanceChart.data.datasets[0].data = data;
            window.performanceChart.update();
            return;
        }

        window.performanceChart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Gains/Pertes cumulés (Ar)',
                    data,
                    borderColor: '#ffd700',
                    backgroundColor: 'rgba(255, 215, 0, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#ffffff' } } },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.1)' }, ticks: { color: '#ffffff' } },
                    x: { grid: { color: 'rgba(255,255,255,0.1)' }, ticks: { color: '#ffffff' } }
                }
            }
        });
    }

    renderProfile(user, categoryBreakdown = {}) {
        const stats = sharedStorageManager.getStats(user.id);

        const set = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };
        const setValue = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.value = value ?? '';
        };

        set('profileName', user.name);
        set('profileEmail', user.email);
        set('profileDate', new Date(user.createdAt).toLocaleDateString('fr-FR'));
        set('profileId', user.id);

        const totalGames = stats.totalGames || 0;
        const totalWins = stats.totalWins || 0;
        const winRate = totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0;
        const profit = (stats.totalWinnings || 0) - (stats.totalLossesAmount || 0);

        set('statGames', totalGames);
        set('statWins', totalWins);
        set('statWinRate', `${winRate}%`);
        set('statProfit', `${profit >= 0 ? '+' : ''}${profit.toLocaleString()} Ar`);

        setValue('editName', user.name);
        setValue('editEmail', user.email);
        setValue('editPhone', user.phone);
        if (user.language) setValue('editLanguage', user.language);

        // Le solde affiché (.user-balance) est resynchronisé par CasinoApp.loadPage()
        // juste après l'appel à renderProfile, avec la valeur réelle et à jour.
        this.updateProfileChart(categoryBreakdown);
    }

    // Crée (ou met à jour) le graphique de répartition des jeux par catégorie de la page profil.
    updateProfileChart(categoryBreakdown) {
        const canvas = document.getElementById('gamePerformanceChart');
        if (!canvas || typeof Chart === 'undefined') return;

        const hasData = Object.keys(categoryBreakdown).length > 0;
        const labels = hasData ? Object.keys(categoryBreakdown) : ['Aucune partie jouée'];
        const data = hasData ? Object.values(categoryBreakdown) : [1];
        const colors = ['#ffd700', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#c41e3a', '#8b4513'];

        if (window.gamePerformanceChart) {
            window.gamePerformanceChart.data.labels = labels;
            window.gamePerformanceChart.data.datasets[0].data = data;
            window.gamePerformanceChart.update();
            return;
        }

        window.gamePerformanceChart = new Chart(canvas.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels,
                datasets: [{
                    data,
                    backgroundColor: colors,
                    borderColor: '#1a1a2e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom', labels: { color: '#ffffff', padding: 20 } } }
            }
        });
    }
}
// Application principale
import { AuthManager } from './auth.js';
import { GamesManager } from './games-manager.js';
import { Chatbot } from './chatbot.js';
import { StorageManager } from './storage.js';
import { UIManager } from './utils.js';
import { HeaderComponent } from '../components/header.js';
import { FooterComponent } from '../components/footer.js';
import { PopupManager } from '../components/popup.js';
import { NavigationManager } from '../components/navigation.js';

class CasinoApp {
    constructor() {
        this.authManager = new AuthManager();
        this.gamesManager = new GamesManager();
        this.chatbot = new Chatbot();
        this.storageManager = new StorageManager();
        this.uiManager = new UIManager();
        this.popupManager = new PopupManager();
        this.navigationManager = new NavigationManager();
        this.currentUser = null;
        this.balance = 0;
    }

    async init() {
        console.log('🎰 Initialisation du Casino Malagasy...');
        
        // Initialiser les composants
        this.renderHeader();
        this.renderFooter();
        this.initChatbot();
        
        // Vérifier l'authentification
        await this.checkAuth();

        // Charger la page depuis l'URL (deep-link) ou la page d'accueil par défaut
        this.navigationManager.loadPageFromHash();

        // Gérer les événements de navigation
        this.setupNavigation();
        
        console.log('✅ Casino Malagasy initialisé avec succès!');
    }

    async checkAuth() {
        const token = this.storageManager.getSecureItem('auth_token');
        if (token) {
            try {
                const userData = this.authManager.verifyToken(token);
                if (userData) {
                    this.currentUser = userData;
                    this.balance = await this.storageManager.getBalance(userData.id);
                    this.updateUIForAuth();
                }
            } catch (error) {
                this.storageManager.removeSecureItem('auth_token');
            }
        }
    }

    updateUIForAuth() {
        const header = document.getElementById('app-header');
        if (this.currentUser) {
            // Mettre à jour l'interface pour utilisateur connecté
            this.uiManager.updateBalance(this.balance);
            this.uiManager.showUserMenu(this.currentUser);
        }
    }

    renderHeader() {
        const headerContainer = document.getElementById('app-header');
        headerContainer.innerHTML = HeaderComponent.render(this.currentUser);
        HeaderComponent.setupEventListeners(this);
    }

    renderFooter() {
        const footerContainer = document.getElementById('app-footer');
        footerContainer.innerHTML = FooterComponent.render();
        FooterComponent.setupEventListeners();
    }

    initChatbot() {
        this.chatbot.init();
    }

    async loadPage(page) {
        const contentContainer = document.getElementById('app-content');
        
        try {
            let html = '';
            
            switch(page) {
                case 'home':
                    html = await this.loadTemplate('pages/home.html');
                    break;
                case 'games':
                    html = await this.loadTemplate('pages/games.html');
                    break;
                case 'history':
                    html = await this.loadTemplate('pages/history.html');
                    break;
                case 'profile':
                    html = await this.loadTemplate('pages/profile.html');
                    break;
                case 'culture':
                    html = await this.loadTemplate('pages/malagasy-culture.html');
                    break;
                case 'login':
                    html = this.authManager.renderLoginForm();
                    break;
                case 'register':
                    html = this.authManager.renderRegisterForm();
                    break;
                default:
                    html = '<h2>Page non trouvée</h2>';
            }
            
            contentContainer.innerHTML = html;
            this.setupPageEvents(page);

            // Resynchroniser l'affichage du solde pour les éléments .user-balance
            // fraîchement injectés dans ce fragment de page (ex: page profil)
            if (this.currentUser) {
                this.uiManager.updateBalance(this.balance);
            }

        } catch (error) {
            console.error('Erreur de chargement:', error);
            contentContainer.innerHTML = '<h2>Erreur de chargement</h2>';
        }
    }

    async loadTemplate(url) {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Erreur HTTP: ${response.status}`);
        return await response.text();
    }

    setupPageEvents(page) {
        switch(page) {
            case 'games':
                this.gamesManager.init(this);
                break;
            case 'history':
                this.loadHistory();
                break;
            case 'profile':
                this.loadProfile();
                break;
            case 'login':
                this.setupLoginForm();
                break;
            case 'register':
                this.setupRegisterForm();
                break;
        }
    }

    setupLoginForm() {
        const form = document.getElementById('loginForm');
        if (!form) return;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;

            try {
                const user = await this.authManager.login(email, password);
                this.currentUser = user;
                this.balance = await this.storageManager.getBalance(user.id);
                this.renderHeader();
                this.uiManager.showToast(`Bienvenue, ${user.name}!`, 'success');
                this.navigationManager.navigateTo('home');
            } catch (error) {
                this.uiManager.showToast(error.message, 'error');
            }
        });
    }

    setupRegisterForm() {
        const form = document.getElementById('registerForm');
        if (!form) return;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const userData = {
                name: document.getElementById('regName').value.trim(),
                email: document.getElementById('regEmail').value.trim(),
                password: document.getElementById('regPassword').value,
                confirmPassword: document.getElementById('regConfirmPassword').value
            };

            try {
                const user = await this.authManager.register(userData);
                this.currentUser = user;
                this.balance = await this.storageManager.getBalance(user.id);
                this.renderHeader();
                this.uiManager.showToast(`Compte créé! Bonus de bienvenue: ${user.balance.toLocaleString()} Ar`, 'success');
                this.navigationManager.navigateTo('home');
            } catch (error) {
                this.uiManager.showToast(error.message, 'error');
            }
        });
    }

    setupNavigation() {
        document.addEventListener('click', (e) => {
            const target = e.target.closest('[data-page]');
            if (target) {
                e.preventDefault();
                const page = target.getAttribute('data-page');
                this.navigationManager.navigateTo(page);
            }
        });
    }

    // precomputedResult permet à un jeu spécifique (slots, roulette, dés, cartes...)
    // de fournir lui-même le résultat déjà déterminé, afin que l'affichage du jeu
    // et la mise à jour réelle du solde restent toujours cohérents entre eux.
    async placeBet(gameId, amount, precomputedResult = null) {
        if (!this.currentUser) {
            this.popupManager.show('error', 'Veuillez vous connecter pour jouer');
            return false;
        }

        if (this.betInProgress) {
            return false; // empêche les doubles soumissions pendant la résolution d'une mise
        }

        if (!Number.isFinite(amount) || amount <= 0) {
            this.popupManager.show('error', 'Mise invalide');
            return false;
        }

        if (amount > this.balance) {
            this.popupManager.show('error', 'Solde insuffisant');
            return false;
        }

        this.betInProgress = true;
        try {
            const result = precomputedResult || await this.gamesManager.playGame(gameId, amount);

            if (result.win) {
                this.balance += result.payout;
                this.popupManager.showWin(result);
            } else {
                this.balance -= amount;
                this.popupManager.showLoss(result);
            }

            this.uiManager.updateBalance(this.balance);
            await this.storageManager.updateBalance(this.currentUser.id, this.balance);
            await this.storageManager.saveGameHistory(this.currentUser.id, result);

            return result;
        } finally {
            this.betInProgress = false;
        }
    }

    showPromotion(promotion) {
        this.popupManager.showPromotion(promotion);
    }

    loadHistory() {
        if (!this.currentUser) return;
        
        const history = this.storageManager.getGameHistory(this.currentUser.id);
        this.uiManager.renderHistory(history);
    }

    loadProfile() {
        if (!this.currentUser) return;

        // Répartition des parties jouées par catégorie de jeu, pour le graphique du profil
        const history = this.storageManager.getGameHistory(this.currentUser.id);
        const categoryBreakdown = {};
        history.forEach(entry => {
            const game = this.gamesManager.games.find(g => g.id === entry.gameId);
            const label = game ? this.gamesManager.getCategoryName(game.category) : 'Autres';
            categoryBreakdown[label] = (categoryBreakdown[label] || 0) + 1;
        });

        this.uiManager.renderProfile(this.currentUser, categoryBreakdown);
    }

    logout() {
        this.authManager.logout();
    }

    clearHistory() {
        if (!this.currentUser) return;
        this.storageManager.clearHistory(this.currentUser.id);
        this.loadHistory();
        this.uiManager.showToast('Historique effacé', 'success');
    }

    // Ajout de fonds virtuels (simulation - aucune transaction réelle)
    addFunds() {
        if (!this.currentUser) return;
        const amount = 5000;
        this.balance += amount;
        this.uiManager.updateBalance(this.balance);
        this.storageManager.updateBalance(this.currentUser.id, this.balance);
        this.uiManager.showToast(`+${amount.toLocaleString()} Ar ajoutés (simulation)`, 'success');
    }

    updateProfile() {
        if (!this.currentUser) return;

        const name = document.getElementById('editName')?.value.trim();
        const phone = document.getElementById('editPhone')?.value.trim();
        const language = document.getElementById('editLanguage')?.value;

        try {
            const updates = { phone, language };
            if (name) updates.name = name;

            const updatedUser = this.authManager.updateUser(this.currentUser.id, updates);
            this.currentUser = updatedUser;
            this.renderHeader();
            this.uiManager.showToast('Profil mis à jour', 'success');
        } catch (error) {
            this.uiManager.showToast(error.message, 'error');
        }
    }

    changePassword() {
        if (!this.currentUser) return;

        const oldPassword = prompt('Mot de passe actuel:');
        if (oldPassword === null) return;
        const newPassword = prompt('Nouveau mot de passe (min. 6 caractères):');
        if (newPassword === null) return;

        try {
            this.authManager.changePassword(this.currentUser.id, oldPassword, newPassword);
            this.uiManager.showToast('Mot de passe modifié avec succès', 'success');
        } catch (error) {
            this.uiManager.showToast(error.message, 'error');
        }
    }

    enable2FA() {
        this.uiManager.showToast('Authentification à deux facteurs: fonctionnalité à venir', 'info');
    }

    changeAvatar() {
        this.uiManager.showToast('Personnalisation d\'avatar: fonctionnalité à venir', 'info');
    }

    deleteAccount() {
        if (!this.currentUser) return;
        const confirmed = confirm('Supprimer définitivement votre compte? Cette action est irréversible.');
        if (!confirmed) return;

        this.authManager.deleteAccount(this.currentUser.id);
    }
}

// Initialiser l'application
document.addEventListener('DOMContentLoaded', () => {
    const app = new CasinoApp();
    app.init();
    
    // Exposer l'application globalement pour le débogage
    window.casinoApp = app;
});
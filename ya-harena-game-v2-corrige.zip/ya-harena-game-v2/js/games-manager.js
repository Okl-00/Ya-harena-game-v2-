export class GamesManager {
    constructor() {
        this.games = this.initializeGames();
        this.currentGame = null;
        this.cardState = null; // état de la main en cours pour les jeux de cartes
    }

    initializeGames() {
        return [
            // Jeux de cartes
            { id: 'blackjack', name: 'Blackjack', category: 'cartes', icon: '♠️', minBet: 100, maxBet: 10000 },
            { id: 'poker', name: 'Poker Malagasy', category: 'cartes', icon: '🃏', minBet: 200, maxBet: 20000 },
            { id: 'baccarat', name: 'Baccarat', category: 'cartes', icon: '🎴', minBet: 100, maxBet: 15000 },
            { id: 'punto-banco', name: 'Punto Banco', category: 'cartes', icon: '🂡', minBet: 150, maxBet: 12000 },
            { id: 'blackjack-switch', name: 'Blackjack Switch', category: 'cartes', icon: '🂦', minBet: 200, maxBet: 15000 },

            // Machines à sous
            { id: 'slots-classic', name: 'Machines à Sous Classic', category: 'slots', icon: '🎰', minBet: 50, maxBet: 5000 },
            { id: 'slots-video', name: 'Video Slots', category: 'slots', icon: '🎮', minBet: 50, maxBet: 5000 },
            { id: 'slots-progressif', name: 'Jackpot Progressif', category: 'slots', icon: '💎', minBet: 100, maxBet: 10000 },
            { id: 'slots-3d', name: 'Slots 3D', category: 'slots', icon: '🎯', minBet: 75, maxBet: 7500 },
            { id: 'slots-fruit', name: 'Fruit Slots', category: 'slots', icon: '🍒', minBet: 25, maxBet: 2500 },

            // Roulettes
            { id: 'roulette-europeenne', name: 'Roulette Européenne', category: 'roulette', icon: '🎡', minBet: 100, maxBet: 20000 },
            { id: 'roulette-americaine', name: 'Roulette Américaine', category: 'roulette', icon: '🎪', minBet: 100, maxBet: 20000 },
            { id: 'roulette-francaise', name: 'Roulette Française', category: 'roulette', icon: '🗼', minBet: 200, maxBet: 25000 },

            // Dés
            { id: 'craps', name: 'Craps', category: 'des', icon: '🎲', minBet: 100, maxBet: 10000 },
            { id: 'sic-bo', name: 'Sic Bo', category: 'des', icon: '🎯', minBet: 50, maxBet: 8000 },
            { id: 'yams', name: 'Yams Casino', category: 'des', icon: '🎳', minBet: 75, maxBet: 7500 },

            // Jeux spéciaux
            { id: 'keno', name: 'Keno', category: 'special', icon: '🎱', minBet: 50, maxBet: 5000 },
            { id: 'bingo', name: 'Bingo', category: 'special', icon: '🎉', minBet: 50, maxBet: 5000 },
            { id: 'scratch', name: 'Cartes à Gratter', category: 'special', icon: '💳', minBet: 25, maxBet: 2500 },
            { id: 'wheel-fortune', name: 'Roue de la Fortune', category: 'special', icon: '☸️', minBet: 100, maxBet: 10000 },
            { id: 'hi-lo', name: 'Hi-Lo', category: 'special', icon: '📈', minBet: 50, maxBet: 5000 },

            // Jeux malagasy
            { id: 'fanorona', name: 'Fanorona Bet', category: 'malagasy', icon: '🏝️', minBet: 200, maxBet: 10000 },
            { id: 'moraingy', name: 'Moraingy Fight', category: 'malagasy', icon: '🥊', minBet: 300, maxBet: 15000 },
            { id: 'savika', name: 'Savika (Tauromachie)', category: 'malagasy', icon: '🐂', minBet: 250, maxBet: 12000 },
            { id: 'diamanga', name: 'Diamanga', category: 'malagasy', icon: '💠', minBet: 150, maxBet: 8000 },
            { id: 'tolon-omby', name: 'Tolon\'omby', category: 'malagasy', icon: '🏟️', minBet: 200, maxBet: 10000 },

            // Poker variants
            { id: 'texas-holdem', name: 'Texas Hold\'em', category: 'poker', icon: '♣️', minBet: 500, maxBet: 50000 },
            { id: 'omaha', name: 'Omaha Poker', category: 'poker', icon: '♦️', minBet: 500, maxBet: 50000 },
            { id: 'stud-poker', name: '7-Card Stud', category: 'poker', icon: '♥️', minBet: 300, maxBet: 30000 }
        ];
    }

    init(app) {
        this.app = app;
        this.renderGamesList();
        this.setupFilters();
        this.setupSearchAndSort();
    }

    renderGamesList() {
        const container = document.getElementById('games-container');
        if (!container) return;

        // Si la page fournit déjà une barre de filtres statique (#categoriesNav, ex: pages/games.html),
        // on ne génère pas de deuxième barre redondante : on se contente de la grille.
        const hasStaticFilterBar = !!document.getElementById('categoriesNav');

        let html = '<div class="container mt-4">';

        if (!hasStaticFilterBar) {
            const categories = this.getCategories();
            html += `
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="btn-group flex-wrap" role="group">
                            <button class="btn btn-outline-warning active" data-filter="all">Tous</button>
                            ${categories.map(cat => `
                                <button class="btn btn-outline-warning" data-filter="${cat.id}">${cat.name}</button>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        }

        // Grille de jeux
        html += '<div class="row" id="games-grid">';
        this.games.forEach(game => {
            html += `
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4 game-item" data-category="${game.category}">
                    <div class="game-card h-100" onclick="casinoApp.gamesManager.openGame('${game.id}')">
                        <div class="game-card-content">
                            <div class="game-icon">${game.icon}</div>
                            <div class="game-title">${game.name}</div>
                            <div class="game-description">
                                Mise: ${game.minBet} - ${game.maxBet} Ar
                            </div>
                            <span class="game-badge">${game.category}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div></div>';

        container.innerHTML = html;
    }

    getCategories() {
        const categories = {};
        this.games.forEach(game => {
            if (!categories[game.category]) {
                categories[game.category] = {
                    id: game.category,
                    name: this.getCategoryName(game.category)
                };
            }
        });
        return Object.values(categories);
    }

    getCategoryName(category) {
        const names = {
            'cartes': '🃏 Cartes',
            'slots': '🎰 Machines à Sous',
            'roulette': '🎡 Roulette',
            'des': '🎲 Dés',
            'special': '⭐ Spéciaux',
            'malagasy': '🇲🇬 Jeux Malagasy',
            'poker': '♠️ Poker'
        };
        return names[category] || category;
    }

    setupFilters() {
        document.querySelectorAll('[data-filter]').forEach(button => {
            button.addEventListener('click', (e) => {
                const btn = e.target.closest('[data-filter]');
                const filter = btn.getAttribute('data-filter');

                // Mise à jour des boutons
                document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                // Filtrage des jeux
                let visibleCount = 0;
                document.querySelectorAll('.game-item').forEach(item => {
                    const match = filter === 'all' || item.getAttribute('data-category') === filter;
                    item.style.display = match ? 'block' : 'none';
                    if (match) visibleCount++;
                });

                const emptyState = document.getElementById('gamesEmpty');
                if (emptyState) emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
            });
        });
    }

    // Recherche et tri (barre de recherche et sélecteur présents sur pages/games.html)
    setupSearchAndSort() {
        const searchInput = document.getElementById('gameSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.searchGames(e.target.value));
        }

        const searchButton = searchInput?.closest('.input-group')?.querySelector('button');
        if (searchButton) {
            searchButton.addEventListener('click', () => this.searchGames(searchInput.value));
        }

        const sortSelect = document.getElementById('gameSort');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => this.sortGames(e.target.value));
        }
    }

    searchGames(term) {
        const searchTerm = (term ?? document.getElementById('gameSearch')?.value ?? '').toLowerCase().trim();
        const gameItems = document.querySelectorAll('.game-item');
        let foundCount = 0;

        gameItems.forEach(item => {
            const gameName = item.querySelector('.game-title')?.textContent.toLowerCase() || '';
            const gameCategory = item.getAttribute('data-category') || '';

            if (!searchTerm || gameName.includes(searchTerm) || gameCategory.includes(searchTerm)) {
                item.style.display = 'block';
                foundCount++;
            } else {
                item.style.display = 'none';
            }
        });

        const emptyState = document.getElementById('gamesEmpty');
        if (emptyState) emptyState.style.display = foundCount === 0 ? 'block' : 'none';
    }

    sortGames(sortBy) {
        const gamesGrid = document.getElementById('games-grid');
        if (!gamesGrid) return;

        const gameItems = Array.from(document.querySelectorAll('.game-item'));

        gameItems.sort((a, b) => {
            const nameA = a.querySelector('.game-title')?.textContent || '';
            const nameB = b.querySelector('.game-title')?.textContent || '';
            const catA = a.getAttribute('data-category') || '';
            const catB = b.getAttribute('data-category') || '';

            switch (sortBy) {
                case 'name':
                    return nameA.localeCompare(nameB);
                case 'category':
                    return catA.localeCompare(catB);
                default:
                    return 0;
            }
        });

        gameItems.forEach(item => gamesGrid.appendChild(item));
    }

    resetFilters() {
        const searchInput = document.getElementById('gameSearch');
        if (searchInput) searchInput.value = '';

        document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
        document.querySelector('[data-filter="all"]')?.classList.add('active');

        document.querySelectorAll('.game-item').forEach(item => item.style.display = 'block');

        const emptyState = document.getElementById('gamesEmpty');
        if (emptyState) emptyState.style.display = 'none';
    }

    openGame(gameId) {
        const game = this.games.find(g => g.id === gameId);
        if (!game) return;

        this.currentGame = game;

        const modal = new bootstrap.Modal(document.getElementById('gameModal'));
        const modalContent = document.getElementById('gameModalContent');

        modalContent.innerHTML = this.renderGameInterface(game);
        modal.show();

        this.setupGameEvents(game);
    }

    renderGameInterface(game) {
        switch (game.category) {
            case 'slots':
                return this.renderSlotMachine(game);
            case 'roulette':
                return this.renderRoulette(game);
            case 'cartes':
                return this.renderCardGame(game);
            case 'des':
                return this.renderDiceGame(game);
            default:
                return this.renderGenericGame(game);
        }
    }

    // Initialise l'état nécessaire selon le type de jeu, une fois le modal affiché
    setupGameEvents(game) {
        if (game.category === 'cartes') {
            this.dealNewCardHand();
        }
    }

    renderSlotMachine(game) {
        return `
            <div class="slot-machine">
                <h3 class="mb-4">${game.name}</h3>
                <div class="slot-reels">
                    <div class="slot-reel" id="reel1">🍒</div>
                    <div class="slot-reel" id="reel2">💎</div>
                    <div class="slot-reel" id="reel3">7️⃣</div>
                </div>
                <div class="mt-4">
                    <label class="form-label">Mise en Ariary</label>
                    <input type="number" class="form-control form-input" id="betAmount"
                           min="${game.minBet}" max="${game.maxBet}" value="${game.minBet}">
                </div>
                <button class="btn btn-casino mt-3" onclick="casinoApp.gamesManager.spinSlots()">
                    🎰 LANCER
                </button>
                <div id="slotResult" class="mt-3"></div>
            </div>
        `;
    }

    async spinSlots() {
        const betAmount = parseInt(document.getElementById('betAmount').value, 10);
        if (!Number.isFinite(betAmount)) return;

        const reels = document.querySelectorAll('.slot-reel');
        const symbols = ['🍒', '💎', '7️⃣', '🎰', '⭐', '🍀', '💰', '👑'];

        // Le résultat est déterminé une seule fois, avant l'animation, pour que
        // l'affichage final des rouleaux corresponde toujours au solde réellement crédité/débité.
        const results = [symbols[Math.floor(Math.random() * symbols.length)],
                          symbols[Math.floor(Math.random() * symbols.length)],
                          symbols[Math.floor(Math.random() * symbols.length)]];

        let multiplier = 0;
        if (results[0] === results[1] && results[1] === results[2]) {
            multiplier = 10;
        } else if (results[0] === results[1] || results[1] === results[2]) {
            multiplier = 2;
        }
        const win = multiplier > 0;

        const gameResult = {
            gameId: this.currentGame.id,
            gameName: this.currentGame.name,
            bet: betAmount,
            win,
            payout: win ? betAmount * multiplier : 0,
            multiplier: win ? multiplier : 0,
            timestamp: new Date().toISOString()
        };

        const result = await this.app.placeBet(this.currentGame.id, betAmount, gameResult);
        if (!result) return;

        document.querySelector('.slot-machine').classList.add('slot-spinning');

        setTimeout(() => {
            document.querySelector('.slot-machine').classList.remove('slot-spinning');
            reels.forEach((reel, index) => reel.textContent = results[index]);

            document.getElementById('slotResult').innerHTML = win
                ? `<div class="alert alert-success animate-fade-in-up">🎉 Félicitations! Vous gagnez ${gameResult.payout.toLocaleString()} Ar!</div>`
                : `<div class="alert alert-warning">Pas de chance! Réessayez!</div>`;
        }, 2000);
    }

    renderRoulette(game) {
        return `
            <div class="roulette-game text-center">
                <h3>${game.name}</h3>
                <div class="roulette-wheel" id="rouletteWheel">
                    <div class="roulette-pointer"></div>
                </div>
                <div class="mt-4">
                    <label class="form-label">Choisissez un numéro (0-36)</label>
                    <input type="number" class="form-control form-input d-inline-block w-auto"
                           id="rouletteNumber" min="0" max="36">
                </div>
                <div class="mt-2">
                    <label class="form-label">Mise en Ariary</label>
                    <input type="number" class="form-control form-input d-inline-block w-auto"
                           id="rouletteBet" min="${game.minBet}" max="${game.maxBet}" value="${game.minBet}">
                </div>
                <button class="btn btn-casino mt-3" onclick="casinoApp.gamesManager.spinRoulette()">
                    🎡 LANCER LA BOULE
                </button>
                <div id="rouletteResult" class="mt-3"></div>
            </div>
        `;
    }

    async spinRoulette() {
        const chosenNumber = parseInt(document.getElementById('rouletteNumber').value, 10);
        const betAmount = parseInt(document.getElementById('rouletteBet').value, 10);

        if (!Number.isFinite(chosenNumber) || chosenNumber < 0 || chosenNumber > 36) {
            document.getElementById('rouletteResult').innerHTML =
                `<div class="alert alert-warning">Choisissez un numéro entre 0 et 36.</div>`;
            return;
        }
        if (!Number.isFinite(betAmount)) return;

        // Résultat déterminé une seule fois, avant l'animation de la roue
        const winningNumber = Math.floor(Math.random() * 37);
        const win = chosenNumber === winningNumber;
        const payout = win ? betAmount * 35 : 0;

        const gameResult = {
            gameId: this.currentGame.id,
            gameName: this.currentGame.name,
            bet: betAmount,
            win,
            payout,
            multiplier: win ? 35 : 0,
            timestamp: new Date().toISOString()
        };

        const result = await this.app.placeBet(this.currentGame.id, betAmount, gameResult);
        if (!result) return;

        const wheel = document.getElementById('rouletteWheel');
        const rotation = 360 * 5 + (winningNumber * (360 / 37));
        wheel.style.transform = `rotate(${rotation}deg)`;

        setTimeout(() => {
            document.getElementById('rouletteResult').innerHTML = win
                ? `<div class="alert alert-success animate-fade-in-up">🎉 Numéro ${winningNumber}! Vous gagnez ${payout.toLocaleString()} Ar!</div>`
                : `<div class="alert alert-info">Numéro ${winningNumber}. Pas de chance!</div>`;
        }, 5000);
    }

    // --- Jeux de cartes (Blackjack simplifié) ---

    createShuffledDeck() {
        const suits = ['♠', '♥', '♦', '♣'];
        const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
        const deck = [];
        suits.forEach(suit => values.forEach(value => deck.push({ suit, value })));

        // Mélange (Fisher-Yates)
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
        return deck;
    }

    handValue(hand) {
        let total = 0;
        let aces = 0;
        hand.forEach(card => {
            if (card.value === 'A') {
                aces++;
                total += 11;
            } else if (['J', 'Q', 'K'].includes(card.value)) {
                total += 10;
            } else {
                total += parseInt(card.value, 10);
            }
        });
        while (total > 21 && aces > 0) {
            total -= 10;
            aces--;
        }
        return total;
    }

    renderHand(hand, hideSecond = false) {
        return hand.map((card, i) => {
            if (hideSecond && i === 1) return '<span class="playing-card">🂠</span>';
            const isRed = card.suit === '♥' || card.suit === '♦';
            return `<span class="playing-card" style="color:${isRed ? '#dc3545' : '#fff'}">${card.value}${card.suit}</span>`;
        }).join(' ');
    }

    dealNewCardHand() {
        const betInput = document.getElementById('cardBet');
        const betAmount = betInput ? parseInt(betInput.value, 10) : this.currentGame.minBet;

        this.cardState = {
            deck: this.createShuffledDeck(),
            playerHand: [],
            dealerHand: [],
            betAmount,
            finished: false
        };
        this.cardState.playerHand.push(this.cardState.deck.pop(), this.cardState.deck.pop());
        this.cardState.dealerHand.push(this.cardState.deck.pop(), this.cardState.deck.pop());

        this.updateCardDisplay(true);
    }

    updateCardDisplay(hideDealer = true) {
        const dealerEl = document.getElementById('dealer-hand');
        const playerEl = document.getElementById('player-hand');
        if (dealerEl) dealerEl.innerHTML = this.renderHand(this.cardState.dealerHand, hideDealer);
        if (playerEl) playerEl.innerHTML = this.renderHand(this.cardState.playerHand, false) +
            ` <span class="text-muted">(${this.handValue(this.cardState.playerHand)})</span>`;
    }

    renderCardGame(game) {
        return `
            <div class="card-game">
                <h3 class="text-center mb-4">${game.name}</h3>
                <div class="blackjack-table text-center">
                    <h5>Main du Croupier</h5>
                    <div id="dealer-hand" class="mb-4"></div>
                    <div class="my-4"></div>
                    <h5>Votre Main</h5>
                    <div id="player-hand" class="mb-4"></div>
                </div>
                <div class="text-center mt-3">
                    <label class="form-label">Mise en Ariary</label>
                    <input type="number" class="form-control form-input d-inline-block w-auto"
                           id="cardBet" min="${game.minBet}" max="${game.maxBet}" value="${game.minBet}">
                </div>
                <div class="text-center mt-3">
                    <button class="btn btn-casino mx-2" onclick="casinoApp.gamesManager.hitCard()">Carte</button>
                    <button class="btn btn-outline-warning mx-2" onclick="casinoApp.gamesManager.standCard()">Rester</button>
                </div>
                <div id="cardResult" class="text-center mt-3"></div>
            </div>
        `;
    }

    hitCard() {
        if (!this.cardState || this.cardState.finished) return;

        this.cardState.playerHand.push(this.cardState.deck.pop());
        this.updateCardDisplay(true);

        if (this.handValue(this.cardState.playerHand) > 21) {
            this.resolveCardGame('bust');
        }
    }

    async standCard() {
        if (!this.cardState || this.cardState.finished) return;

        // Le croupier tire jusqu'à 17
        while (this.handValue(this.cardState.dealerHand) < 17) {
            this.cardState.dealerHand.push(this.cardState.deck.pop());
        }
        this.updateCardDisplay(false);

        const playerTotal = this.handValue(this.cardState.playerHand);
        const dealerTotal = this.handValue(this.cardState.dealerHand);

        if (dealerTotal > 21 || playerTotal > dealerTotal) {
            await this.resolveCardGame('win');
        } else if (playerTotal === dealerTotal) {
            await this.resolveCardGame('push');
        } else {
            await this.resolveCardGame('lose');
        }
    }

    async resolveCardGame(outcome) {
        this.cardState.finished = true;
        const betAmount = this.cardState.betAmount;
        const win = outcome === 'win';

        if (outcome === 'bust') {
            this.updateCardDisplay(false);
        }

        const gameResult = {
            gameId: this.currentGame.id,
            gameName: this.currentGame.name,
            bet: betAmount,
            win,
            payout: win ? betAmount * 2 : 0,
            multiplier: win ? 2 : 0,
            timestamp: new Date().toISOString()
        };

        const messages = {
            win: `<div class="alert alert-success animate-fade-in-up">🎉 Vous gagnez ${gameResult.payout.toLocaleString()} Ar!</div>`,
            lose: `<div class="alert alert-warning">Le croupier gagne. Pas de chance!</div>`,
            bust: `<div class="alert alert-warning">Dépassé 21! Vous perdez la main.</div>`,
            push: `<div class="alert alert-info">Égalité! Votre mise est remboursée.</div>`
        };

        if (outcome === 'push') {
            // Égalité : ni gain ni perte, la mise n'est pas engagée dans placeBet
            document.getElementById('cardResult').innerHTML = messages.push;
        } else {
            const result = await this.app.placeBet(this.currentGame.id, betAmount, gameResult);
            if (result) {
                document.getElementById('cardResult').innerHTML = messages[outcome];
            }
        }
    }

    renderDiceGame(game) {
        return `
            <div class="dice-game text-center">
                <h3>${game.name}</h3>
                <div class="dice-container my-4">
                    <div class="dice" id="dice1">⚀</div>
                    <div class="dice" id="dice2">⚁</div>
                </div>
                <div>
                    <label class="form-label">Mise en Ariary</label>
                    <input type="number" class="form-control form-input d-inline-block w-auto"
                           id="diceBet" min="${game.minBet}" max="${game.maxBet}" value="${game.minBet}">
                </div>
                <div class="mt-3">
                    <label class="form-label">Parier sur la somme (2-12)</label>
                    <input type="number" class="form-control form-input d-inline-block w-auto"
                           id="diceGuess" min="2" max="12">
                </div>
                <button class="btn btn-casino mt-3" onclick="casinoApp.gamesManager.rollDice()">
                    🎲 LANCER LES DÉS
                </button>
                <div id="diceResult" class="mt-3"></div>
            </div>
        `;
    }

    async rollDice() {
        const betAmount = parseInt(document.getElementById('diceBet').value, 10);
        const guess = parseInt(document.getElementById('diceGuess').value, 10);

        if (!Number.isFinite(guess) || guess < 2 || guess > 12) {
            document.getElementById('diceResult').innerHTML =
                `<div class="alert alert-warning">Choisissez une somme entre 2 et 12.</div>`;
            return;
        }
        if (!Number.isFinite(betAmount)) return;

        const die1 = Math.floor(Math.random() * 6) + 1;
        const die2 = Math.floor(Math.random() * 6) + 1;
        const sum = die1 + die2;
        const win = sum === guess;

        // Multiplicateur inversement proportionnel à la probabilité d'obtenir cette somme
        const waysToRoll = { 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 5, 9: 4, 10: 3, 11: 2, 12: 1 };
        const multiplier = win ? Math.round(36 / waysToRoll[guess]) : 0;

        const gameResult = {
            gameId: this.currentGame.id,
            gameName: this.currentGame.name,
            bet: betAmount,
            win,
            payout: win ? betAmount * multiplier : 0,
            multiplier,
            timestamp: new Date().toISOString()
        };

        const result = await this.app.placeBet(this.currentGame.id, betAmount, gameResult);
        if (!result) return;

        const faces = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
        document.getElementById('dice1').textContent = faces[die1];
        document.getElementById('dice2').textContent = faces[die2];

        document.getElementById('diceResult').innerHTML = win
            ? `<div class="alert alert-success animate-fade-in-up">🎉 Somme ${sum}! Vous gagnez ${gameResult.payout.toLocaleString()} Ar!</div>`
            : `<div class="alert alert-warning">Somme ${sum}. Pas de chance!</div>`;
    }

    renderGenericGame(game) {
        return `
            <div class="generic-game text-center p-5">
                <div class="game-icon" style="font-size: 5rem;">${game.icon}</div>
                <h3>${game.name}</h3>
                <p>Jeu en cours de développement</p>
                <label class="form-label">Mise en Ariary</label>
                <input type="number" class="form-control form-input d-inline-block w-auto"
                       id="genericBet" min="${game.minBet}" max="${game.maxBet}" value="${game.minBet}">
                <button class="btn btn-casino mt-3" onclick="casinoApp.gamesManager.playGeneric()">
                    JOUER
                </button>
                <div id="genericResult" class="mt-3"></div>
            </div>
        `;
    }

    async playGeneric() {
        const betAmount = parseInt(document.getElementById('genericBet').value, 10);
        if (!Number.isFinite(betAmount)) return;

        const result = await this.app.placeBet(this.currentGame.id, betAmount);
        if (!result) return;

        document.getElementById('genericResult').innerHTML = result.win
            ? `<div class="alert alert-success animate-fade-in-up">🎉 Félicitations! Vous gagnez ${result.payout.toLocaleString()} Ar!</div>`
            : `<div class="alert alert-warning">Pas de chance! Réessayez!</div>`;
    }

    // Logique de jeu générique utilisée par playGeneric() (jeux sans interface dédiée)
    async playGame(gameId, amount) {
        const win = Math.random() < 0.45; // 45% de chance de gagner
        const multiplier = win ? (Math.random() * 2 + 1) : 0;

        return {
            gameId: gameId,
            gameName: this.games.find(g => g.id === gameId)?.name || 'Jeu inconnu',
            bet: amount,
            win: win,
            payout: win ? Math.floor(amount * multiplier) : 0,
            multiplier: multiplier,
            timestamp: new Date().toISOString()
        };
    }
}
